#include <stdio.h>
int main(void) {
   int longSide = 12;
   int shortSide = 10;

   int perimeter = 2 * (longSide + shortSide);

   printf("Sides: %d %d\n", longSide, shortSide);
   printf("Perimeter: %d\n", perimeter);
   
   return 0;
}
