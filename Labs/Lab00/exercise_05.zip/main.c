#include <stdio.h>
int main(void) {
   int proportion = 6;

   printf("Is Pluto a planet?\n");
   printf("Some people think so, ");
   printf("but others don't.\n");
   printf("The Moon's mass is %d times Pluto's.\n", proportion);
   printf("Not much of a planet, is it?\n");

   return 0;
}
