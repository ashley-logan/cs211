#include <stdio.h>
int main(int) {
    int dodgers;
    int yankees;
    int orioles;
   scanf("%d", &dodgers);
   scanf("%d", &yankees);
   scanf("%d", &orioles);
   printf("Last night the Dodgers scored %d,\n", dodgers);
   printf("the Yankees scored %d, and\n", yankees);
   printf("the Cubs scored %d.\n", orioles);

   return 0;
}
